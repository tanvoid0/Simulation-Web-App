package SingleServerQueuingSystem;

import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import java.awt.Font;
import java.awt.Toolkit;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.awt.event.ActionEvent;
import javax.swing.JProgressBar;
import javax.swing.ImageIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class SSQS extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextArea resultTA;
	private JProgressBar progressBar;
	String time = "";
	private JLabel clockLbl;
	private JButton btnCalculate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SSQS frame = new SSQS();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	Timer tm = new Timer(2, this);
	int t = 0;

	public void logic() {
		t++;
		progressBar.setValue(t);
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (t != 100) {
			logic();
		} else {
			tm.stop();
			ServerCalculation();

		}
		repaint();
	}

	private void FrameInMiddle() {

		Dimension screenSize, frameSize;
		int x, y;
		screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frameSize = getSize();
		x = (screenSize.width - frameSize.width) / 2;
		y = (screenSize.height - frameSize.height) / 2;
		setLocation(x, y);

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}
		SwingUtilities.updateComponentTreeUI(contentPane);
	}

	private void ServerCalculation() {
		float avgser = 0, qavg = 0, savg = 0;
		int i, no, wcount = 0, icount = 0, j;
		no = Integer.parseInt(textField.getText());
		int arrival[] = { 1, 2, 3, 4, 5, 6, 7, 8 };
		int arrivalrda[] = new int[arrival.length];
		float cumarrival[] = new float[arrival.length];
		float arrivalprob[] = { 0.125f, 0.125f, 0.125f, 0.125f, 0.125f, 0.125f, 0.125f, 0.125f };
		int arrivaltime[] = new int[no];
		int service[] = { 1, 2, 3, 4, 5, 6 };
		float serviceprob[] = { 0.10f, 0.20f, 0.30f, 0.25f, 0.10f, 0.05f };
		float servicecum[] = new float[service.length];
		int servicerda[] = new int[service.length];
		int servicetime[] = new int[no];
		int randomarrival[] = new int[no];
		int randomservice[] = new int[no];
		int interarrival[] = new int[no];
		int starttime[] = new int[no];
		int endtime[] = new int[no];
		int ttq[] = new int[no];
		int tts[] = new int[no];
		int idletime[] = new int[no];
		for (i = 0; i < arrival.length; i++) {
			if (i == 0) {
				cumarrival[i] = arrivalprob[i];
				arrivalrda[i] = (int) (cumarrival[i] * 100);
			}

			else {
				cumarrival[i] = cumarrival[i - 1] + arrivalprob[i];
				arrivalrda[i] = (int) (cumarrival[i] * 100);
			}
		}
		for (i = 0; i < service.length; i++) {
			if (i == 0) {
				servicecum[i] = serviceprob[i];
				servicerda[i] = (int) (servicecum[i] * 100);
			} else {
				servicecum[i] = servicecum[i - 1] + serviceprob[i];
				servicerda[i] = (int) (servicecum[i] * 100);
			}
		}
		randomservice[0] = (int) (Math.random() * 100d);
		for (i = 1; i < no; i++) {
			randomarrival[i] = (int) (Math.random() * 100d);
			randomservice[i] = (int) (Math.random() * 100d);
		}
		for (i = 1; i < no; i++) {
			for (j = 0; j < arrivalrda.length; j++) {
				if (randomarrival[i] == 0) {
					arrivaltime[i] = arrival[arrival.length - 1];
					break;
				}
				if (randomarrival[i] <= arrivalrda[j]) {
					arrivaltime[i] = arrival[j];
					break;
				}
			}
			interarrival[i] = interarrival[i - 1] + arrivaltime[i];
		}
		for (i = 0; i < no; i++) {
			for (j = 0; j < servicerda.length; j++) {
				if (randomservice[i] == 0) {
					servicetime[i] = service[service.length - 1];
					break;
				}
				if (randomservice[i] <= servicerda[j]) {
					servicetime[i] = service[j];
					break;
				}
			}
		}
		for (i = 0; i < no; i++) {
			if (i == 0) {
				starttime[i] = 0;
				endtime[i] = starttime[i] + servicetime[i];
				tts[i] = servicetime[i];
			} else {
				if (endtime[i - 1] >= interarrival[i]) {
					ttq[i] = endtime[i - 1] - interarrival[i];
					starttime[i] = endtime[i - 1];
					endtime[i] = starttime[i] + servicetime[i];
					tts[i] = servicetime[i] + ttq[i];
				} else {
					idletime[i] = interarrival[i] - endtime[i - 1];
					starttime[i] = interarrival[i];
					endtime[i] = starttime[i] + servicetime[i];
					tts[i] = servicetime[i];
				}
			}
		}
		for (i = 0; i < no; i++) {
			avgser = avgser + servicetime[i];
			qavg = qavg + ttq[i];
			savg = savg + tts[i];
			if (ttq[i] > 0)
				wcount++;
			if (idletime[i] > 0)
				icount++;
		}

		System.out.println("CNo.\tRDIA.\tIART.\tART.\tRDS.\tTSBEG.\tSERT.\tSEND.\tTCWQ.\tIDLTS.\tTCSIS.");
		for (i = 0; i < no; i++) {
			System.out.println((i + 1) + "\t" + randomarrival[i] + "\t" + arrivaltime[i] + "\t" + interarrival[i] + "\t"
					+ randomservice[i] + "\t" + starttime[i] + "\t" + servicetime[i] + "\t" + endtime[i] + "\t" + ttq[i]
					+ "\t" + idletime[i] + "\t" + tts[i]);

		}

		System.out.println("\nOutputs: \n");

		System.out.println("Average Service Time:\t\t\t\t" + (avgser / no));

		if (wcount > 0)

			System.out.println("Average Waiting Time of the Customer:\t\t" + (qavg / wcount));

		System.out.println("Probability of Time Customer Waits in Queue:\t" + ((float) wcount / no));

		System.out.println("Average Time Spent By Customer in the System:\t" + (savg / no));

		System.out.println("Probability of Idle Time of Server is:\t\t" + ((float) icount / no));

		btnCalculate.setEnabled(false);

	}

	private void pdf() {
		try {
			boolean complete = resultTA.print();
			if (complete) {
				JOptionPane.showMessageDialog(null, "PDF Generated...", null, JOptionPane.INFORMATION_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(null, "Error Occured...", null, JOptionPane.ERROR_MESSAGE);
			}
		} catch (PrinterException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}

	public void clock() {
		Thread clock = new Thread() {
			public void run() {
				try {
					for (;;)
					// while(true);
					{
						Calendar cal = new GregorianCalendar();
						SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy  hh:mm a");
						Date date = cal.getTime();
						String timeString = formatter.format(date);
						clockLbl.setText(timeString);
						sleep(1000);
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};
		clock.start();
	}

	/**
	 * Create the frame.
	 */
	public SSQS() {

		innitialize();
		progressBar.setVisible(false);
		FrameInMiddle();
		clock();

	}

	private void innitialize() {
		setTitle("Single Server Queuing System");
		setIconImage(Toolkit.getDefaultToolkit().getImage(SSQS.class.getResource("/images/server.png")));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 820, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblSingleServerQueuing = new JLabel("Single Server Queuing System");
		lblSingleServerQueuing.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSingleServerQueuing.setHorizontalAlignment(SwingConstants.CENTER);
		lblSingleServerQueuing.setBounds(138, 0, 478, 26);
		contentPane.add(lblSingleServerQueuing);

		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {

				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					btnCalculate.doClick();
				}

			}
		});
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField.setBounds(275, 37, 86, 30);
		contentPane.add(textField);
		textField.setColumns(10);

		JLabel lblEnterNumberOf = new JLabel("Enter Number of Customers:");
		lblEnterNumberOf.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblEnterNumberOf.setBounds(20, 34, 233, 35);
		contentPane.add(lblEnterNumberOf);

		btnCalculate = new JButton("Calculate");
		btnCalculate.setIcon(new ImageIcon(SSQS.class.getResource("/images/calcu.png")));
		btnCalculate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if (textField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Enter Number of Customers");
				} else {
					progressBar.setVisible(true);
					tm.start();
				}

			}
		});
		btnCalculate.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnCalculate.setBounds(386, 37, 217, 30);
		contentPane.add(btnCalculate);

		JButton btnReset = new JButton("");
		btnReset.setIcon(new ImageIcon(SSQS.class.getResource("/images/reload.png")));
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				SSQS frame = new SSQS();
				frame.setVisible(true);
			}
		});

		progressBar = new JProgressBar();
		progressBar.setBounds(10, 76, 781, 9);
		contentPane.add(progressBar);
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnReset.setBounds(631, 34, 70, 33);
		contentPane.add(btnReset);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 87, 781, 461);
		contentPane.add(scrollPane);

		resultTA = new JTextArea();
		scrollPane.setViewportView(resultTA);
		resultTA.setFont(new Font("Monospaced", Font.PLAIN, 15));
		PrintStream printStream = new PrintStream(new CustomOutputStream(resultTA));

		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (resultTA.getText().equals(null)) {
					JOptionPane.showMessageDialog(null, "Calculate First");
				} else {
					pdf();
				}
			}
		});
		button.setIcon(new ImageIcon(SSQS.class.getResource("/images/print.png")));
		button.setFont(new Font("Tahoma", Font.PLAIN, 14));
		button.setBounds(711, 34, 70, 33);
		contentPane.add(button);

		clockLbl = new JLabel("");
		clockLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		clockLbl.setBounds(637, 0, 147, 26);
		contentPane.add(clockLbl);
		System.setOut(printStream);
		System.setErr(printStream);
	}
}
